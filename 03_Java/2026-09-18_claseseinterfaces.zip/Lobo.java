public class Lobo extends Mamifero implements Animal {
    
    // Constructor
    public Lobo(String nombre) {
        super(nombre); // Crea el objeto utilizando el constructor de su clase superior
    }
    
    // Polimorfismo por sobreescritura de métodos
    @Override // Sobrescritura de un método en la interfaz Animal
    public void expresarse() {
        System.out.println("Auuuu");
    }
    
    @Override // Sobrescritura de un método en la interfaz Animal
    public double velocidadMetrosPorSegundo() {
        return 14.0;
    }
}