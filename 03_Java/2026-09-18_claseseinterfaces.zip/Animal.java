public interface Animal {
    // La interfaz contiene métodos abstractos
    void expresarse();
    double velocidadMetrosPorSegundo();
    void alimentarse(TipoAlimentacion tipo);
}