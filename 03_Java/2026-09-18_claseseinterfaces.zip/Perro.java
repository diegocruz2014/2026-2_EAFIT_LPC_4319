public class Perro extends Mamifero implements Animal, Domesticable {
    
    // Constructor
    public Perro(String nombre) {
        super(nombre); // Crea el objeto utilizando el constructor de su clase superior
    }
    
    // Polimorfismo por sobreescritura de métodos
    @Override // Sobrescritura de un método en la interfaz Animal
    public void expresarse() {
        System.out.println("Guau");
    }
    
    @Override // Sobrescritura de un método en la interfaz Animal
    public double velocidadMetrosPorSegundo() {
        return 2.0;
    }
    
    @Override // Sobrescritura de un método en la interfaz Domesticable
    public void responderAlLlamado(String llamado) {
        System.out.println("Escucho \"" + llamado + "\" y acudo de inmediato");
    }
}