import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Main
{
	public static void main(String[] args) {
		
		List<Animal> fauna = new ArrayList<Animal>(); // Herencia, de una clase (List) a un objeto (fauna) utilizando el constructor ArrayList
		
		fauna.add(new Gato("Paco"));        // Gato    -> Animal
		fauna.add(new Perro("Firulais"));   // Perro   -> Animal
		fauna.add(new Lobo("Ulises"));      // Lobo    -> Animal

        for (Animal a : fauna) {
            String nombre = "(sin nombre)";
            
            if (a instanceof Mamifero) {
                Mamifero m = (Mamifero) a;
                nombre = m.getNombre();
            }
            
            System.out.println("\nNombre del animal: " + nombre);
		
		    a.expresarse();
		    a.alimentarse(TipoAlimentacion.;HOGAR);
		    System.out.println(String.format(Locale.US, 
		        "Recorro %.1f metros en un segundo", a.velocidadMetrosPorSegundo()));
		    
		    if(a instanceof Mamifero) {
		        Mamifero m = (Mamifero) a;
		        m.amamantar();
		    }
		    
		    if(a instanceof Domesticable) {
		        Domesticable d = (Domesticable) a;
		        d.responderAlLlamado("ven aca");
		    }
		    else {
		        System.out.println("No responde a llamados humanos");
		    }
        }
        
		System.out.println("");
	}
}
