// Debemos crear la clase como abstracta

// Abstracción: Creación de una clase con atributos y métodos
public abstract class Mamifero {
    
    // Atributos (características, propiedades que obtendrán las clases y los objetos)
    // Se manipulan los atributos de la clase/objeto a través del encapsulamiento, haciendo
    // uso de los métodos Setter (asignar) y Getter (obtener)
    private String nombre; 
    
    
    // Métodos (acciones que lleva a cabo la clase y/o el objeto creado, funciones)
    // Constructor
    public Mamifero(String nombre) {
        this.nombre = nombre;
    }
    
    // Métodos propios de la clase
    public void amamantar() {
        System.out.println("Tomo leche proveniente de mi madre");
    }
    
    public void alimentarse(TipoAlimentacion tipo) {
        switch(tipo) {
            case HOGAR:
                System.out.println("Vivo en un hogar, me alimento de concentrado");
                break;
            case CALLE:
                System.out.println("Me alimento de lo que encuentro en la calle");
                break;
            case SILVESTRE:
                System.out.println("Cazo mi propio alimento");
                break;
            default:
                System.out.println("No han definido de qué me alimento");
                
        }
    }
    
    
    
    
    // Setter y Getter
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getNombre() {
        return nombre;
    }
    
}