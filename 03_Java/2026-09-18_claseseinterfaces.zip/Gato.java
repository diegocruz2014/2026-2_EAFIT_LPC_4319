// Herencia simple de clase (extends Mamifero)
// mas herencia múltiple de tipos (implements Animal, Domesticable)

public class Gato extends Mamifero implements Animal, Domesticable {
    
    // Constructor
    public Gato(String nombre) {
        super(nombre); // Crea el objeto utilizando el constructor de su clase superior
    }
    
    // Polimorfismo por sobreescritura de métodos
    @Override // Sobrescritura de un método en la interfaz Animal
    public void expresarse() {
        System.out.println("Miau");
    }
    
    @Override // Sobrescritura de un método en la interfaz Animal
    public double velocidadMetrosPorSegundo() {
        return 4.0;
    }
    
    @Override // Sobrescritura de un método en la interfaz Domesticable
    public void responderAlLlamado(String llamado) {
        System.out.println("Escucho \"" + llamado + "\" y decido si voy");
    }
}