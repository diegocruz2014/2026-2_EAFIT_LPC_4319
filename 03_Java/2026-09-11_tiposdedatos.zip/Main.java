

public class Main
{
	public static void main(String[] args) {
		
		// Tipos primitivos
		
		// Booleano (lógico)
		boolean a = true;
		a = !(3 + 2 == 1) || false;
		System.out.println("\nTipo: boolean");
		System.out.println("Valor booleano: " + a);
		
		// Caracter
		char letra = '\"';
		Character letra2 = new Character('a');
		System.out.println("\n" + letra);
		System.out.println("Tipo: char");
		System.out.println("Tamaño en bits: " + Character.SIZE);
		System.out.println("Tamaño en bytes: " + Character.BYTES);
		
		// Enteros
		
		// Byte
		byte num1 = 127;
	    System.out.println("\nTipo: byte");
		System.out.println("Valor: " + num1);
		System.out.println("Tamaño en bits: " + Byte.SIZE);
		System.out.println("Tamaño en bytes: " + Byte.BYTES);
		System.out.println("Valor mínimo: " + Byte.MIN_VALUE);
		System.out.println("Valor máximo: " + Byte.MAX_VALUE);
		
		// Short
		short num2 = 32767;
	    System.out.println("\nTipo: short");
		System.out.println("Valor: " + num2);
		System.out.println("Tamaño en bits: " + Short.SIZE);
		System.out.println("Tamaño en bytes: " + Short.BYTES);
		System.out.println("Valor mínimo: " + Short.MIN_VALUE);
		System.out.println("Valor máximo: " + Short.MAX_VALUE);
	    
	    // Integer
		int num3 = 2147483647;
	    System.out.println("\nTipo: int");
		System.out.println("Valor: " + num3);
		System.out.println("Tamaño en bits: " + Integer.SIZE);
		System.out.println("Tamaño en bytes: " + Integer.BYTES);
		System.out.println("Valor mínimo: " + Integer.MIN_VALUE);
		System.out.println("Valor máximo: " + Integer.MAX_VALUE);
		
		// Long
		long num4 = 9223372036854775807L;
	    System.out.println("\nTipo: long");
		System.out.println("Valor: " + num4);
		System.out.println("Tamaño en bits: " + Long.SIZE);
		System.out.println("Tamaño en bytes: " + Long.BYTES);
		System.out.println("Valor mínimo: " + Long.MIN_VALUE);
		System.out.println("Valor máximo: " + Long.MAX_VALUE);
		
		// Floating-point
		
		// Float
		float num5 = 3.4028235E38F;
	    System.out.println("\nTipo: float");
		System.out.println("Valor: " + num5);
		System.out.println("Tamaño en bits: " + Float.SIZE);
		System.out.println("Tamaño en bytes: " + Float.BYTES);
		System.out.println("Valor mínimo: " + Float.MIN_VALUE);
		System.out.println("Valor máximo: " + Float.MAX_VALUE);
		
		// Double
		double num6 = 1.7976931348623157E308;
	    System.out.println("\nTipo: double");
		System.out.println("Valor: " + num6);
		System.out.println("Tamaño en bits: " + Double.SIZE);
		System.out.println("Tamaño en bytes: " + Double.BYTES);
		System.out.println("Valor mínimo: " + Double.MIN_VALUE);
		System.out.println("Valor máximo: " + Double.MAX_VALUE);
		
		// Tipo de dato genérico
		
		var cualquier = 3.14;
		System.out.println("\nTipo: var");
		System.out.println("Valor: " + cualquier);
		
		System.out.println("\nPolimorfismo (adhoc) en la suma:");
		System.out.println(2 + 3);
		System.out.println('2' + 3);
		System.out.println(2 + '3');
		System.out.println('2' + '3');
		System.out.println((char)('2' + '3'));
		System.out.println("2" + 3);
		System.out.println(2 + "3");
		System.out.println("2" + "3");
		System.out.println(2 + 3 + "4");
		System.out.println("2" + 3 + 4);
		
		System.out.println('a' + 1);
		System.out.println("" + 'a' + 1);
		
		
	}
}
