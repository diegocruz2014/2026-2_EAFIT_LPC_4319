% Hechos
madre(matilde, tom).
madre(matilde, ana).
madre(ana, luisa).
padre(alfonso, tom).
padre(alfonso, ana).

% Reglas
hijo(X, Y):- madre(Y, X); padre(Y, X). 
hermano(X, Y):- madre(Z, X), madre(Z, Y),
                padre(W, X), padre(W, Y),
                X \= Y.

% Construcción de la función principal
main:-
        proceso,
        halt.

% Construcción de un proceso secundario
proceso:-
        write('Hijos de Ana: '),
        findall(X, hijo(X, ana), HijosAna),
        write(HijosAna), nl,
        write('Hijos de Matilde: '),
        findall(X, hijo(X, matilde), HijosMatilde),
        write(HijosMatilde), nl,
        write('Hermanos: '),
        findall((X, Y), hermano(X, Y), Hermanos),
        write(Hermanos), nl.

% Ejecución de la función principal
:- main.