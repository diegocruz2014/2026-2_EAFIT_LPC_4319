% Se indica que el predicado main se ejecuta al iniciar 
:- initialization(main).

% Importar biblioteca readutil para utilizar el método read_line_to_string. Este 
% método hace una lectura línea por línea de un contenido.
:- use_module(library(readutil)).

% Crear el predicado principal para crear un archivo y mostrar su contenido
main:-
    write_students_file,
    read_students_file,
    halt.

% Predicado (método) para crear/abrir un archivo y escribirlo
write_students_file:-
    % Crear/abrir un archivo en modo escritura
    open('students.txt', write, Contenido),
    %Escribir tres datos de estudiantes en él
    writeln(Contenido, 'Ana - Ingeniería de Sistemas'),
    writeln(Contenido, 'Luisa - Ingeniería de Diseño de Productos'),
    writeln(Contenido, 'Samuel - Administración de Empresas'),
    % Cerrar el archivo
    close(Contenido),
    writeln('El archivo students.txt se creó exitosamente.').
    
% Predicado para abrir el archivo en modo lectura y mostrar sus líneas.
read_students_file :-
    open('students.txt', read, Contenido),
    writeln('--- Estudiantes en el archivo ---'),
    read_lines(Contenido),
    close(Contenido).

% Predicado (función o método) para leer un contenido pasado como parámetro 
% línea por línea y terminar cuando se alcance el fin del archivo
read_lines(Contenido):-
    read_line_to_string(Contenido, Linea),
    ( Linea == end_of_file ->
        true
    ;
        writeln(Linea),
        read_lines(Contenido)
    ).






