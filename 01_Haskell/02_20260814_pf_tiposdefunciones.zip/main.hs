-- Una función se crea o se declara con la forma:
-- nombreFuncion param1 param2 ... paramN = cuerpoFuncion

-- Función pura: A la(s) entrada(s) siempre les corresponde la(s) misma(s) salida(s)
doble x = x + x

-- Estructura condicional
esPar :: Int -> String    -- Declaración de firma o tipo
esPar 0 = "El cero es múltiplo de todos los números enteros"
esPar x = 
    if mod x 2 == 0
        then "El valor ingresado es par"
    else "El valor ingresado es impar"


-- Funciones de orden superior: reciben una función como parámetro de entrada
-- o salida
duplicarLista :: [Integer] -> [Integer]
duplicarLista = map doble  -- map es la función de orden superior

filtrarParesLista :: [Integer] -> [Integer] 
filtrarParesLista = filter (\x -> mod x 2 == 0) -- Entre los paréntesis está una abstracción lambda o función anónima

incrementarLista :: [Integer] -> [Integer]
incrementarLista = map (+1)

-- Coincidencia de patrones (pattern matching)
numeroDeLaSuerte :: Integer -> String
numeroDeLaSuerte 7 = "Adivinaste el num. de la suerte!"
numeroDeLaSuerte 1 = "Este es otro num. de la suerte!"
numeroDeLaSuerte x = "Sigue intentando..."

-- Operador de composición (.)
combinar :: [Integer] -> [Integer]
combinar = incrementarLista . duplicarLista . filtrarParesLista

-- Recursividad
-- Función para crear una lista
crearLista :: Integer -> [Integer] -> [Integer]
crearLista x y =
    if x == 1
        then y 
    else
        crearLista (x-1) ((x-1):y)





main :: IO()  -- Declaración de firma o tipo de función
main = do
    putStrLn "Hello World" -- Imprimir en pantalla
    let a = 5 -- Para expresiones secuenciales o aritméticas utilizamos let
    let b = 2
    
    -- operaciones
    putStrLn $ show(a + b)
    putStrLn $ show(0.1 + 0.2)
    
    let mult = a * b
    print(mult)
    putStrLn $ show(a) ++ " x " ++ show(b) ++ " = " ++ show(mult)
    
    -- Fuciones propias
    putStrLn $ show(397 / 3)
    putStrLn $ show(div 397 3)      -- Función de forma prefija
    --putStrLn $ show(397 `div` 3)    -- Función de forma infija
    
    -- Funciones creadas
    putStrLn $ show(doble a)
    
    -- Generadores de listas
    putStrLn $ show([2..10])
    putStrLn $ show([1,11..100])
    putStrLn $ show([10,9..1])
    putStrLn $ show([3,6..30])
    
    -- Evaluación perezosa
    print(take 3 [0..])
    print(take 3 (drop 5 [0..]))
    --print([5, head [], 7] !! 2)
    
    -- Funciones propias
    let lista = [1..10]
    print(doble a)
    print(numeroDeLaSuerte 1)
    print(esPar 0)
    print(duplicarLista lista)
    print(filtrarParesLista lista)
    print(incrementarLista lista)
    print(combinar lista)
    print(crearLista 5 [])
    
    
    
    
    
    
    
    
    
    
    
    