doble x = x + x

main :: IO()  -- Declaración de firma o tipo de función
main = do
    putStrLn "Hello World" -- Imprimir en pantalla
    let a = 5 -- Para expresiones secuenciales o aritméticas utilizamos let
    let b = 2
    
    -- operaciones
    putStrLn $ show(a + b)
    putStrLn $ show(0.1 + 0.2)
    
    let mult = a * b
    print(mult)
    putStrLn $ show(a) ++ " x " ++ show(b) ++ " = " ++ show(mult)
    
    -- Fuciones propias
    putStrLn $ show(397 / 3)
    putStrLn $ show(div 397 3)      -- Función de forma prefija
    --putStrLn $ show(397 `div` 3)    -- Función de forma infija
    
    -- Funciones creadas
    putStrLn $ show(doble a)
    
    -- Generadores de listas
    putStrLn $ show([2..10])
    putStrLn $ show([1,11..100])
    putStrLn $ show([10,9..1])
    putStrLn $ show([3,6..30])
    
    
    