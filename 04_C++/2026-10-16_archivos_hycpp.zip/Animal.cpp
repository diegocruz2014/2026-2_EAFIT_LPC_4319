#include "Animal.h"

// Constructor
Animal::Animal() {}

// Métodos propios de la clase Animal, que se van a sobreescribir 
// en las clases que los heredan

void Animal::expresarse() {
    cout << "Por definir" << endl;
}

string Animal::desplazarse() {
    return "Por definir";
}

void Animal::alimentarse(string tipo) {
    cout << "Por definir" << endl;
}
