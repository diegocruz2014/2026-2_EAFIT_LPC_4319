#include "Mamifero.h"

// Constructor
Mamifero::Mamifero(string nombre) {
    this->nombre = nombre;
}

// Setter y Getter
void Mamifero::setNombre(string nombre) {
    this->nombre = nombre;
}

string Mamifero::getNombre() {
    return nombre;
}

// Métodos propios de la clase
void Mamifero::amamantar() {
    cout << "Tomo leche proveniente de mi madre" << endl;
}
