#include "Perro.h"

int main()
{
    // Crear la instancia (objeto) de la clase Perro
    Perro max("Max", 2);

    // Realizar acciones con el objeto creado
    cout << "Nombre del perro: " << max.getNombre() << endl;
    cout << "Edad: " << max.getEdad() << endl;
    max.expresarse();
    cout << max.desplazarse() << endl;
    max.alimentarse("CALLEjero");
    max.amamantar();
    
    return 0;
}