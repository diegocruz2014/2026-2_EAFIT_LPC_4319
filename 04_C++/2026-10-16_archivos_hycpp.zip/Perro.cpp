#include "Perro.h"

// Constructor
Perro::Perro(string nombre, int edad) : Mamifero(nombre) {
    this->edad = edad;
}

// Método para convertir en minúsculas un texto
string Perro::toLower(string cad) {
    std::transform(cad.begin(), cad.end(), cad.begin(),
        [](unsigned char c){ return std::tolower(c); });
    return cad;
}

// Métodos provenientes de la clase Animal
void Perro::expresarse() {
    cout << "Guau" << endl;
}

string Perro::desplazarse() {
    return "Recorro dos metros en un segundo";
}

void Perro::alimentarse(string tipo) {
    if (toLower(tipo) == "hogareño") {
        cout << "Vivo en un hogar, me alimento de concentrado" << endl;
    }
    else if (toLower(tipo) == "callejero") {
        cout << "Me alimento de lo que encuentro en la calle" << endl;
    }
    else if (toLower(tipo) == "silvestre") {
        cout << "Cazo mi propio alimento" << endl;
    }
    else {
        cout << "No se ha definido de qué me alimento" << endl;
    }
}

// Setter y Getter
void Perro::setEdad(int edad) {
    this->edad = edad;
}

int Perro::getEdad() {
    return edad;
}

