#ifndef MAMIFERO_H
#define MAMIFERO_H

#include <iostream>
using namespace std;

class Mamifero {
    private: 
        // Los elementos establecidos al interior del modificador de acceso 
        // private se utilizan a través de encapsulamiento.
        // Atributos internos de la clase
        string nombre;
    public:
        // Constructor
        Mamifero(string nombre);
        // Setter y Getter
        void setNombre(string nombre);
        string getNombre();
        // Métodos propios de la clase
        void amamantar();
};

#endif