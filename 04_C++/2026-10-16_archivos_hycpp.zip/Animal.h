// Las siguientes dos líneas se utilizan entre otras cosas, para evitar el
// problema del diamante
#ifndef ANIMAL_H
#define ANIMAL_H

#include <iostream>
using namespace std;

class Animal {
    
    public:
        // Constructor
        Animal();
        
        // Métodos propios de la clase Animal
        virtual void expresarse(); // Virtual para informar que los métodos se van a sobreescribir
        virtual string desplazarse();
        virtual void alimentarse(string tipo);
};

#endif