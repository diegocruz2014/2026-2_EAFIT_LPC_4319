#ifndef PERRO_H
#define PERRO_H

#include <algorithm>    // Necesaria para transform (realizar acciones en arreglos de elementos)
#include <cctype>       // Necesaria para tolower (convertir una letra de mayúscula a minúscula)
#include "Animal.h"
#include "Mamifero.h"

// Herencia múltiple en C++
class Perro : public Animal, public Mamifero {
    private:
        int edad;
        string toLower(string cad);
    
    public:
        // Constructor
        Perro(string nombre, int edad);
        
        // Métodos heredados
        void expresarse() override;
        string desplazarse() override;
        void alimentarse(string tipo) override;
        
        // Setter y Getter
        void setEdad(int edad);
        int getEdad();
}; 




#endif