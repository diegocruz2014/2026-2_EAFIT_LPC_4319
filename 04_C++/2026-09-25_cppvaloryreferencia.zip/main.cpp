#include <iostream>
using namespace std;

// Variable global
int variable = 5;

void cambiarValor1(int y) {
    y = variable;
    cout << "Valor de \"x \" dentro de la función: " << y << endl;
}

void cambiarValor2(int &y) {
    y = variable;
    cout << "Valor de \"x \" dentro de la función: " << y << endl;
}


int main()
{
    int x = 28;
    int *px = &x;
    
    cout << "Asignación de parámetro por valor: " << endl;
    cout << "Valor de \"x \" antes de la función: " << x << endl;
    cambiarValor1(x);
    cout << "Valor de \"x \" después de la función: " << x << endl;
    
    cout << "\nAsignación de parámetro por referencia: " << endl;
    cout << "Valor de \"x \" antes de la función: " << x << endl;
    cambiarValor2(x);
    cout << "Valor de \"x \" después de la función: " << x << endl;
    
    cout << "\nDirección de memoria de la variable \"x\": " << px;
    
    return 0;
}